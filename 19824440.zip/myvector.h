/*myvector.h*/

// 
// <YOUR NAME>
// Wajahat Khan
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Wajahat Khan
//Wkhan25

// Project #01: myvector class that mimics std::vector, but with my own
// implemenation outlined as follows:
//
// So, i've implemented a linked list with head and tail pointer(which is normal (I KNOW)):) with extra pointer that take care of the last node
// i mean in the at function if the user is searching in order than our loop works in (O(1)) manner. If user chose not to 
// follow the pattern than the code will take him to the else condition which is (O(n)). 
// SUMMARY: i tried to fasten the code by increasing the speed of Size function and at function (if the proper order is followed)
// 

#pragma once

#include <iostream>  // print debugging
#include <cstdlib>   // malloc, free

using namespace std;

// my template class
template<typename T>

class myvector
{
private:
	//struct Node
	struct Node
	{
		T data;
		struct Node* next;

	}*first = NULL;

	int Size = 0;
	Node *lastnode = NULL;
	int lastindex;
	T* A;
public:
	// default constructor of the class
	myvector()
	{

		first = NULL;
		lastnode = NULL;
		lastindex = -1;

	}
	//constructor with parameters
	myvector(int initialize)
	{
		for (int i = 0; i < initialize; i++)
		{

			push_back(T{});
		}


	}
	//here is the copy constructor
	myvector(const myvector& other)
	{
		Node *n = new Node;
		n = other.first;
		while (n != NULL)
		{
			push_back(n->data);
			n = n->next;
		}



	}
	//size of the function (at first i was traversing the whole linked list and counting it but later changed it)
	int size()
	{
		//int count = 0;
		//Node *n;
		//n = first;
		//while (n != NULL)
		//{
		//	count++;
		///	n = n->next;
	///	}
		//return count;
		return Size;
	}

//at function to find the elements

	T& at(int i)
	{
		Node *w = first;
		//this whole process is the O(1) works if you follow the pattern
		if (i == 0)
		{
			lastnode = first;
			lastindex = 0;
			return first->data;
		}
		//
		else if (i == lastindex + 1)
		{
			lastnode = lastnode->next;
			lastindex++;
			return lastnode->data;

		}
		//This process is O(n) will work on random given values
		else {
			if (i < 0)
			{
				cout << "please input correct values" << endl;
			}
			int k = 0;
			while ((w->next != NULL) && (k != i))
			{
				w = w->next;
				k++;
				if (k == i)
				{
					return w->data;
				}

			}
		}
		return w->data;
	}


	//push back function adding elements in the linked list
	Node *Tail = NULL;

	void push_back(T value)
	{
		Node *n;

		//first = new Node;
		//first->data = value;
		//first->next = NULL;
		//kind of tail pointer

		n = new Node;
		n->data = value;
		n->next = NULL;

		if (first == NULL)
		{

			first = n;
			Tail = n;
			n = NULL;
		}

		else
		{
			//w = w->next;
			Tail->next = n;
			Tail = n;
		}
		Size++;

	}

	//erasing the elements from the linked list
	T erase(int i)
	{
		Node * currNode;
		Node* sucNode = NULL;
		currNode = first;

		//this is the special case if the key is HEAD then this will remove
			if (currNode != NULL && currNode->data == at(i))
			{
				first = currNode->next;
				sucNode = currNode;

			}
			if (i == 0)
			{
				Size--;
				return sucNode->data;

			}

		//searching for the key (traversing the list)
		while (currNode != NULL && currNode->data != at(i))
		{
			sucNode = currNode;
			currNode = currNode->next;

		}
		sucNode->next = currNode->next;
		Size--;

	
		return currNode->data;
	}
	//operator function same as at just the syntax difference V.at(i) --> v[i]
	T& operator [](int i)
	{

		//you have to make read and write
		//simply call at function

		return at(i);
	}

	// To find the range between the given elements with dynamically allocated array
	T* rangeof(int i, int j)
	{
		Node* currNode = new Node;
		currNode = first;

		A = new T[Size];

		for (int m = 0; m < Size; m++)
		{
			A[m] = 0;
		}
		int k = 0;
		int l = 0;
		
		if (i == j)
		{
			for (int l = 0; l < 1; l++)
			{
				A[l] = at(i);
				return A;
			}
		}
		else
		{
			// This is the special case here it will find the data between the gien range
			int  m = 0;

			while (m != i)
			{
				currNode = currNode->next;
				m++;
			}

			for (k = 0; k <= j; k++)
			{
				if (currNode == NULL)
				{
					break;
				}
				else
				{
					A[k] = currNode->data;
					currNode = currNode->next;
				}

				//was just testing

				//	cout << "The data at position = " << k << " is : " << A[k] << endl;

			}
		}
		return A;

	}
};
